
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<br><br>
	<table class="table1" width="600">
		<tr>
				<th>글번호</th>
				<th>글제목</th>
				<th>작성자</th>
				<th>작성일</th>
				<th>조회수</th>
		</tr>
		<tr>
				<td>글번호</td>
				<td>글제목</td>
				<td>작성자</td>
				<td>작성일</td>
				<td>조회수</td>
		</tr>
		<tr>
				<td colspan="5" align="center">
					<input type="button" class="bt1" value="공지사항추가" onclick="location.href='notice_write.php'">
				</td>
		</tr>
	</table>
</body>
</html>